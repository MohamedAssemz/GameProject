package units;

import exceptions.FriendlyFireException;

public class Infantry extends Unit {

	public Infantry(int level, int maxSoldierConunt, double idleUpkeep, double marchingUpkeep, double siegeUpkeep) {
		super(level, maxSoldierConunt, idleUpkeep, marchingUpkeep, siegeUpkeep);
	}
	
public void attack(Unit target) throws FriendlyFireException {
		
		if (target.getCurrentSoldierCount() == 0 || this.getParentArmy().equals(target.getParentArmy())) 
				throw new FriendlyFireException(); 
		
		
		else {
			
		if ( this.getLevel() == 1) {
		   if ( target instanceof Archer )
			   target.setCurrentSoldierCount((int) (0.3*target.getCurrentSoldierCount()));
		   else 
			   if ( target instanceof Infantry )
				   target.setCurrentSoldierCount((int) (0.1*target.getCurrentSoldierCount()));
			   else 
				   if ( target instanceof Cavalry )
					   target.setCurrentSoldierCount((int) (0.1*target.getCurrentSoldierCount()));
	          }
		
		if ( this.getLevel() == 2) {
			   if ( target instanceof Archer )
				   target.setCurrentSoldierCount((int) (0.4*target.getCurrentSoldierCount()));
			   else 
				   if ( target instanceof Infantry )
					   target.setCurrentSoldierCount((int) (0.2*target.getCurrentSoldierCount()));
				   else 
					   if ( target instanceof Cavalry )
						   target.setCurrentSoldierCount((int) (0.2*target.getCurrentSoldierCount()));
		          }
		
		if ( this.getLevel() == 3) {
			   if ( target instanceof Archer )
				   target.setCurrentSoldierCount((int) (0.5*target.getCurrentSoldierCount()));
			   else 
				   if ( target instanceof Infantry )
					   target.setCurrentSoldierCount((int) (0.3*target.getCurrentSoldierCount()));
				   else 
					   if ( target instanceof Cavalry )
						   target.setCurrentSoldierCount((int) (0.25*target.getCurrentSoldierCount()));
		          }
		
	
		}
		
	}
	
	
	
}
