package units;

import java.util.ArrayList;
import java.util.Collections;

import exceptions.MaxCapacityException;

/**
 * @author mohammad.hussein
 *
 */
public class Army{
	private Status currentStatus;
	private ArrayList<Unit> units;
	private int distancetoTarget;
	private String target;
	private String currentLocation;
	private String name;
	@SuppressWarnings("unused")
	private final int maxToHold=10;

	public Army(String currentLocation, String name) {
		this.currentLocation=currentLocation;
		currentStatus=Status.IDLE;
		units=new ArrayList<Unit>();
		distancetoTarget=-1;
		target="";
		this.name = name;
	}
	public Status getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(Status currentStatus) {
		this.currentStatus = currentStatus;
	}

	public ArrayList<Unit> getUnits() {
		return units;
	}

	public void setUnits(ArrayList<Unit> units) {
		this.units = units;
	}

	public int getDistancetoTarget() {
		return distancetoTarget;
	}

	public void setDistancetoTarget(int distancetoTarget) {
		this.distancetoTarget = distancetoTarget;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	public String getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}
	public int getMaxToHold() {
		return maxToHold;
	}
	public void relocateUnit(Unit unit) throws MaxCapacityException{
        if(this.units.size() < maxToHold) {
        	unit.getParentArmy().getUnits().remove(unit);
        	unit.setParentArmy(this);
        	this.getUnits().add(unit);
        }
        else {
        	 throw new MaxCapacityException();
        }
	}
	
	public void handleAttackedUnit(Unit u) {
		if(this.getUnits().contains(u) && u.getCurrentSoldierCount()==0) {
			this.getUnits().remove(u) ; 
			}	
	}
	public double foodNeeded() {
		double food =0;
		
		if (this.currentStatus == Status.IDLE) {
			for ( int i=0;i<units.size(); i++)
				{ food += units.get(i).getIdleUpkeep()*units.get(i).getCurrentSoldierCount();}
		}
		
		if (this.currentStatus == Status.MARCHING) {
			for ( int i=0;i<units.size(); i++)
				{ food += units.get(i).getMarchingUpkeep()*units.get(i).getCurrentSoldierCount();}
		}
		
		if (this.currentStatus == Status.BESIEGING) {
			for ( int i=0;i<units.size(); i++)
				{ food += units.get(i).getSiegeUpkeep()*units.get(i).getCurrentSoldierCount();}
		}
		return food;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void organize() {
		Collections.sort(this.getUnits());
	}
	
}
