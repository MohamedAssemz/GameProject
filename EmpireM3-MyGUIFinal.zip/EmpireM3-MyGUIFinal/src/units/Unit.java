package units;

import exceptions.FriendlyFireException;

public abstract class Unit implements Comparable<Unit>{
	private int level;
	private int maxSoldierCount;
	private int currentSoldierCount;
	private double idleUpkeep;
	private double marchingUpkeep;
	private double siegeUpkeep;
	private Army parentArmy;

	public Unit(int level, int maxSoldierConunt, double idleUpkeep, double marchingUpkeep, double siegeUpkeep) {
		this.level = level;
		this.maxSoldierCount = maxSoldierConunt;
		this.idleUpkeep = idleUpkeep;
		this.marchingUpkeep = marchingUpkeep;
		this.siegeUpkeep = siegeUpkeep;
		this.currentSoldierCount = maxSoldierCount; 

	}

	public int getCurrentSoldierCount() {
		return currentSoldierCount;
	}

	public void setCurrentSoldierCount(int d) {
		this.currentSoldierCount = d;
	}

	public int getLevel() {
		return level;
	}

	public int getMaxSoldierCount() {
		return maxSoldierCount;
	}

	public double getIdleUpkeep() {
		return idleUpkeep;
	}

	public double getMarchingUpkeep() {
		return marchingUpkeep;
	}

	public double getSiegeUpkeep() {
		return siegeUpkeep;
	}
	
	public abstract void attack(Unit target) throws FriendlyFireException;

	public Army getParentArmy() {
		return parentArmy;
	}

	public void setParentArmy(Army parentArmy) {
		this.parentArmy = parentArmy;
	}
	
	@Override
	public int compareTo(Unit comparesto) {
		int myValue = 0;
		int theirValue = 0;
		if(this instanceof Archer) {
			switch(this.getLevel()) {
			case 3: myValue = 9;
			case 2: myValue = 8;
			case 1: myValue = 7;
			}
		}
		else if(this instanceof Infantry) {
			switch(this.getLevel()) {
			case 3: myValue = 6;
			case 2: myValue = 5;
			case 1: myValue = 4;
			}
		}
		else if(this instanceof Cavalry) {
			switch(comparesto.getLevel()) {
			case 3: myValue = 3;
			case 2: myValue = 2;
			case 1: myValue = 1;
			}
		}
		if(comparesto instanceof Archer) {
			switch(comparesto.getLevel()) {
			case 3: theirValue = 9;
			case 2: theirValue = 8;
			case 1: theirValue = 7;
			}
		}
		else if(comparesto instanceof Infantry) {
			switch(comparesto.getLevel()) {
			case 3: theirValue = 6;
			case 2: theirValue = 5;
			case 1: theirValue = 4;
			}
		}
		else if(comparesto instanceof Cavalry) {
			switch(comparesto.getLevel()) {
			case 3: theirValue = 3;
			case 2: theirValue = 2;
			case 1: theirValue = 1;
			}
		}
		return myValue - theirValue;
	}
	
}
