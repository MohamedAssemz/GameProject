package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import engine.Game;

public final class StartingPanel extends JPanel implements ActionListener{
	
	private JButton startGameButton;
	private JTextField nameInputField;
	private JComboBox homeInputField;
	
	/*-----------------------------------------------*/
	
	public StartingPanel() {
		this.setBackground(Color.magenta);
		this.setLayout(new BorderLayout());
		
		JPanel title = new JPanel();
		title.setBackground(Color.red);
		title.setPreferredSize(new Dimension(1280, 240));
		this.add(title, BorderLayout.NORTH);
		
		JLabel titleText = new JLabel();
		titleText.setText("The Conqueror");
		titleText.setHorizontalAlignment(JLabel.CENTER);
		titleText.setVerticalAlignment(JLabel.CENTER);
		title.add(titleText);
		
		/*-----------------------------------------------*/
		
		JPanel nameInput = new JPanel();
		nameInput.setBackground(Color.green);
		this.add(nameInput, BorderLayout.CENTER);
		
		JLabel nameInputText = new JLabel();
		nameInputText.setText("Name: ");
		nameInput.add(nameInputText);
		
		nameInputField = new JTextField();
		nameInputField.setPreferredSize(new Dimension(120, 30));
		nameInputText.setLabelFor(nameInputField);
		nameInput.add(nameInputField);
		
		JLabel homeInputText = new JLabel();
		homeInputText.setText("Home City: ");
		nameInput.add(homeInputText);
		
		String[] possibleCityNames = {"Cairo", "Sparta", "Rome"};
		homeInputField = new JComboBox(possibleCityNames);
		homeInputField.setPreferredSize(new Dimension(120, 30));
		homeInputText.setLabelFor(homeInputField);
		nameInput.add(homeInputField);
		
		/*-----------------------------------------------*/
		
		JPanel startGameButtonPanel = new JPanel();
		startGameButtonPanel.setBackground(Color.orange);
		startGameButtonPanel.setPreferredSize(new Dimension(1280, 240));
		this.add(startGameButtonPanel, BorderLayout.SOUTH);
		
		this.startGameButton = new JButton("Start Game");
		this.startGameButton.addActionListener(this);
		startGameButtonPanel.add(startGameButton);
	}

	@Override
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == startGameButton) {
			if(nameInputField.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "Please enter a name!", "Warning", JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				try {
					Main.openMapView(new Game(nameInputField.getText(), homeInputField.getSelectedItem().toString()));
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			}
		}
	}
}
