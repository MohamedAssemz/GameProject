package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import engine.City;
import engine.Game;
import exceptions.FriendlyCityException;
import exceptions.MaxCapacityException;
import exceptions.TargetNotReachedException;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Status;
import units.Unit;

public class MapViewPanel extends JPanel implements ActionListener{
	private Game game;
	private JPanel armiesPanel;
	private JPanel mapPanel;
	private JButton cairoButton;
	private JButton spartaButton;
	private JButton romeButton;
	private JButton openArmyManager;
	private JComboBox playerArmiesBox;
	private ArmyInfoBox armyInfo;
	private Army[] playerArmiesArray;
	private boolean isCairoYours;
	private boolean isSpartaYours;
	private boolean isRomeYours;
	
	public MapViewPanel(Game game) {
		this.game = game;
		this.setLayout(new BorderLayout());
		
		armiesPanel = new JPanel();
		armiesPanel.setBackground(Color.cyan);
		armiesPanel.setPreferredSize(new Dimension(640, this.getHeight()));
		this.add(armiesPanel, BorderLayout.EAST);
		
		mapPanel = new JPanel();
		mapPanel.setBackground(Color.yellow);
		this.add(mapPanel, BorderLayout.CENTER);
		
		/*-----------------------------------------------------------------------------*/
		
		cairoButton = new JButton("Cairo");
		JTextArea cairoInfo = new JTextArea();
		cairoInfo.setEditable(false);
		String cairoText = "";
		City c = null;
		for(int i = 0; i < game.getAvailableCities().size(); i++) {
			if(game.getAvailableCities().get(i).getName().equals("Cairo")) {
				c = game.getAvailableCities().get(i);
			}
		}
		isCairoYours = false;
		for(int i = 0; i < game.getPlayer().getControlledCities().size(); i++) {
			if(game.getPlayer().getControlledCities().get(i).getName().equals("Cairo")) {
				isCairoYours = true;
			}
		}
		if(isCairoYours) {
			cairoText += "Owner: You \n";
		}
		else {
			cairoButton.setEnabled(false);
			cairoText += "Owner: Enemy \n";
		}
		cairoText += "Besieged: " + c.isUnderSiege();
		if(c.getTurnsUnderSiege() > 0) {
			cairoText += "Turns Under Siege:" + c.getTurnsUnderSiege() + "\n";
		}
		cairoInfo.setWrapStyleWord(true);
		cairoInfo.setEditable(false);
		JScrollPane cairoInfoScroll = new JScrollPane(cairoInfo, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);	//from StackOverflaw
		armiesPanel.add(cairoInfoScroll);
		cairoInfo.setText(cairoText);
		
		/*-----------------------------------------------------------------------------*/
		
		spartaButton = new JButton("Sparta");
		JTextArea spartaInfo = new JTextArea();
		spartaInfo.setEditable(false);
		String spartaText = "";
		City s = null;
		for(int i = 0; i < game.getAvailableCities().size(); i++) {
			if(game.getAvailableCities().get(i).getName().equals("Sparta")) {
				s = game.getAvailableCities().get(i);
			}
		}
		isSpartaYours = false;
		for(int i = 0; i < game.getPlayer().getControlledCities().size(); i++) {
			if(game.getPlayer().getControlledCities().get(i).getName().equals("Sparta")) {
				isSpartaYours = true;
			}
		}
		if(isSpartaYours) {
			spartaText += "Owner: You \n";
		}
		else {
			spartaButton.setEnabled(false);
			spartaText += "Owner: Enemy \n";
		}
		spartaText += "Besieged: " + s.isUnderSiege();
		if(s.getTurnsUnderSiege() > 0) {
			spartaText += "Turns Under Siege:" + s.getTurnsUnderSiege() + "\n";
		}
		spartaInfo.setWrapStyleWord(true);
		spartaInfo.setEditable(false);
		JScrollPane spartaInfoScroll = new JScrollPane(spartaInfo, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);	//from StackOverflaw
		armiesPanel.add(spartaInfoScroll);
		spartaInfo.setText(spartaText);
		
		/*-----------------------------------------------------------------------------*/
		
		romeButton = new JButton("Rome");
		JTextArea romeInfo = new JTextArea();
		romeInfo.setEditable(false);
		String romeText = "";
		City r = null;
		for(int i = 0; i < game.getAvailableCities().size(); i++) {
			if(game.getAvailableCities().get(i).getName().equals("Rome")) {
				r = game.getAvailableCities().get(i);
			}
		}
		isRomeYours = false;
		for(int i = 0; i < game.getPlayer().getControlledCities().size(); i++) {
			if(game.getPlayer().getControlledCities().get(i).getName().equals("Rome")) {
				isRomeYours = true;
			}
		}
		if(isRomeYours) {
			romeText += "Owner: You \n";
		}
		else {
			romeButton.setEnabled(false);
			romeText += "Owner: Enemy \n";
		}
		romeText += "Besieged: " + s.isUnderSiege();
		if(r.getTurnsUnderSiege() > 0) {
			romeText += "Turns Under Siege:" + s.getTurnsUnderSiege() + "\n";
		}
		romeInfo.setWrapStyleWord(true);
		romeInfo.setEditable(false);
		JScrollPane romeInfoScroll = new JScrollPane(romeInfo, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);	//from StackOverflaw
		armiesPanel.add(romeInfoScroll);
		romeInfo.setText(romeText);
		
		/*-----------------------------------------------------------------------------*/
		
		mapPanel.add(cairoButton);
		mapPanel.add(cairoInfo);
		
		mapPanel.add(spartaButton);
		mapPanel.add(spartaInfo);
		
		mapPanel.add(romeButton);
		mapPanel.add(romeInfo);
		

		for(int i = 0; i <game.getPlayer().getControlledArmies().size(); i++) {
			if(game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equals("Cairo")) {
				cairoButton.setEnabled(true);
			}
		}
		for(int i = 0; i <game.getPlayer().getControlledArmies().size(); i++) {
			if(game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equals("Sparta")) {
				spartaButton.setEnabled(true);
			}
		}
		for(int i = 0; i <game.getPlayer().getControlledArmies().size(); i++) {
			if(game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equals("Rome")) {
				romeButton.setEnabled(true);
			}
		}

		cairoButton.addActionListener(this);
		spartaButton.addActionListener(this);
		romeButton.addActionListener(this);
		
		/*----------------------------------------------------------------------------------*/
		
		JLabel armiesOverviewTitle = new JLabel("Armies");
		armiesPanel.add(armiesOverviewTitle);
		
		ArmyInfoBox[] armyInfoBoxesArray = new ArmyInfoBox[game.getPlayer().getControlledArmies().size()];
		for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
			armyInfoBoxesArray[i] = new ArmyInfoBox(game.getPlayer().getControlledArmies().get(i), game);
			armiesPanel.add(armyInfoBoxesArray[i]);
		}
		
		
		
		openArmyManager = new JButton("Open Army Manager");
		openArmyManager.addActionListener(this);
		armiesPanel.add(openArmyManager);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(game.getCurrentTurnCount() < 50) {
		if(e.getSource() == cairoButton) {
			if(isCairoYours) {
				for(int i = 0; i < game.getAvailableCities().size(); i++) {
					if(game.getAvailableCities().get(i).getName().equals("Cairo")) {
						Main.openCityManagerPanel(game, game.getAvailableCities().get(i));
					}
				}
			}
			else {
				for(int i = 0; i < game.getAvailableCities().size(); i++) {
					if(game.getAvailableCities().get(i).getName().equals("Cairo")) {
						Main.openBattlePanel(game, game.getAvailableCities().get(i));
					}
				}
			}
		}
		if(e.getSource() == spartaButton) {
			if(isSpartaYours) {
				for(int i = 0; i < game.getAvailableCities().size(); i++) {
					if(game.getAvailableCities().get(i).getName().equals("Sparta")) {
						Main.openCityManagerPanel(game, game.getAvailableCities().get(i));
					}
				}
			}
			else {
				for(int i = 0; i < game.getAvailableCities().size(); i++) {
					if(game.getAvailableCities().get(i).getName().equals("Sparta")) {
						Main.openBattlePanel(game, game.getAvailableCities().get(i));
					}
				}
			}
		}
		if(e.getSource() == romeButton) {
			if(isRomeYours) {
				for(int i = 0; i < game.getAvailableCities().size(); i++) {
					if(game.getAvailableCities().get(i).getName().equals("Rome")) {
						Main.openCityManagerPanel(game, game.getAvailableCities().get(i));
					}
				}
			}
			else {
				for(int i = 0; i < game.getAvailableCities().size(); i++) {
					if(game.getAvailableCities().get(i).getName().equals("Rome")) {
						Main.openBattlePanel(game, game.getAvailableCities().get(i));
					}
				}
			}
		}
		
		if(e.getSource() == openArmyManager) {
			String[] options = {"Target a City", "Change Army Status", "Move a Unit", "Create a New Army"};
			String[] armyNames = new String[game.getPlayer().getControlledArmies().size()];
			for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
				armyNames[i] = game.getPlayer().getControlledArmies().get(i).getName();
			}
			String[] statuses = {"Idle", "Marching"};
			String[] cities = {"Cairo", "Sparta", "Rome"};
			String choice = (String) JOptionPane.showInputDialog(null, "What would you like to do?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, options, "Target a City");
			
			if(choice.equals("Target a City")) {
				String armyTargetingS= (String) JOptionPane.showInputDialog(null, "Which army do you want to use?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				String targetCity = (String) JOptionPane.showInputDialog(null, "What city should it target?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, cities, "Cairo");
				for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
					if(armyTargetingS.equals(game.getPlayer().getControlledArmies().get(i).getName())) {
						game.targetCity(game.getPlayer().getControlledArmies().get(i), targetCity);
					}
				}
			}
			
			if(choice.equals("Change Army Status")) {
				String armyTargeting = (String) JOptionPane.showInputDialog(null, "Which army?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
					boolean setStatus = false;
					Army a = null;
					String newStatus = null;
					if(armyTargeting.equals(game.getPlayer().getControlledArmies().get(i).getName())) {
						a = game.getPlayer().getControlledArmies().get(i);
						for(int j = 0; j < game.getAvailableCities().size(); i++) {
							if(a.equals(game.getAvailableCities().get(j).getDefendingArmy())) {
								JOptionPane.showMessageDialog(null, "Sorry, defending armies are only allowed to idle.");
								break;
							}
							else {
								newStatus = (String) JOptionPane.showInputDialog(null, "What do you want it to do?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, statuses, "Idle");
								if(newStatus.equals("Idle")){
									a.setCurrentStatus(Status.IDLE);
									break;
								}
								if(newStatus.equals("Marching")){
									if(a.getTarget().equals("")) {
										JOptionPane.showMessageDialog(null, "Sorry, can't start marching without a target.");
										break;
									}
									a.setCurrentStatus(Status.MARCHING);
									a.setCurrentLocation("Travelling");
									break;
								}
							}
						}
					}
				}
				
			}
			
			if(choice.equals("Move a Unit")) {
				String armySourceS = (String) JOptionPane.showInputDialog(null, "Which army is the unit in?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				Army armySourceA = null;
				Unit movingUnit = null;
				boolean move = true;
				for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
					if(armySourceS.equals(game.getPlayer().getControlledArmies().get(i).getName())){
						armySourceA = game.getPlayer().getControlledArmies().get(i);
					}
				}
				String[] armySUnitsNames = new String[armySourceA.getUnits().size()];
				Unit[] armySUnits = new Unit[armySourceA.getUnits().size()]; 
				armySourceA.organize();
				for(int i = 0; i < armySourceA.getUnits().size(); i++) {
					Unit u = armySourceA.getUnits().get(i);
					armySUnits[i] = u;
					if(u instanceof Archer) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Archer" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
					}
					if(u instanceof Infantry) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Infantry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
					}
					if(u instanceof Cavalry) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Cavalry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
					}
				}
				if(armySourceA.getUnits().isEmpty()) {
					move = false;
					JOptionPane.showMessageDialog(null, "This army is empty.");
				}
				else {
					String movingUnitName = (String) JOptionPane.showInputDialog(null, "Which unit do you want to move?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armySUnitsNames, armySUnitsNames[0]);
					movingUnit = armySUnits[Integer.parseInt(movingUnitName.charAt(0)+ "") - 1];
				}
				String armyDestinationS = (String) JOptionPane.showInputDialog(null, "Which army should it go to?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				Army armyDestinationA = null;
				if(move) {
					for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
						if(armyDestinationS.equals(game.getPlayer().getControlledArmies().get(i).getName())){
							armyDestinationA = game.getPlayer().getControlledArmies().get(i);
						}
					}
					try {
						armyDestinationA.relocateUnit(movingUnit);
					} catch (MaxCapacityException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, "Sorry, this army is at maximum capacity.");
						e1.printStackTrace();
					}
				}
			}
			
			if(choice.equals("Create a New Army")) {
				String homeCityS = null;
				City homeCity = null;
				Unit firstUnit = null;
				String[] ownedCities = new String[game.getPlayer().getControlledCities().size()];
				for(int i = 0; i < ownedCities.length; i++) {
					ownedCities[i] = game.getPlayer().getControlledCities().get(i).getName();
				}
				homeCityS = (String) JOptionPane.showInputDialog(null, "Where do you want to create this army?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, ownedCities, ownedCities[0]);
				for(int i = 0; i < ownedCities.length; i++) {
					if(homeCityS.equals(game.getPlayer().getControlledCities().get(i).getName())) {
						homeCity = game.getPlayer().getControlledCities().get(i);
					}
				}
				String armySourceS = (String) JOptionPane.showInputDialog(null, "Which army do you want to take the first unit from?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				Army armySourceA = null;
				for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
					if(armySourceS.equals(game.getPlayer().getControlledArmies().get(i).getName())){
						armySourceA = game.getPlayer().getControlledArmies().get(i);
					}
				}
				String[] armySUnitsNames = new String[armySourceA.getUnits().size()];
				Unit[] armySUnits = new Unit[armySourceA.getUnits().size()]; 
				armySourceA.organize();
				for(int i = 0; i < armySourceA.getUnits().size(); i++) {
					Unit u = armySourceA.getUnits().get(i);
					armySUnits[i] = u;
					if(u instanceof Archer) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Archer" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
					}
					if(u instanceof Infantry) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Infantry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
					}
					if(u instanceof Cavalry) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Cavalry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
					}
				}
				if(armySourceA.getUnits().isEmpty()) {
					JOptionPane.showMessageDialog(null, "This army is empty.");
				}
				else {
					String movingUnitName = (String) JOptionPane.showInputDialog(null, "Which unit do you want to move?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armySUnitsNames, armySUnitsNames[0]);
					firstUnit = armySUnits[Integer.parseInt(movingUnitName.charAt(0)+ "") - 1];
				}
				String armyName = (String) JOptionPane.showInputDialog(null, "What do you want to name your army?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, null, null);
				game.getPlayer().initiateArmy(homeCity, firstUnit, armyName);
				
			}
			Main.openMapView(game);
		}
		
		if(e.getSource() == playerArmiesBox) {
			armiesPanel.remove(armyInfo);
			Army a = playerArmiesArray[playerArmiesBox.getSelectedIndex()];
			ArmyInfoBox newArmyInfo = new ArmyInfoBox(a, game);
			armiesPanel.add(newArmyInfo);
			armiesPanel.validate();
			armiesPanel.repaint();
		}
	  }
		else {
			cairoButton.setVisible(false);
			spartaButton.setVisible(false);
			romeButton.setVisible(false);
			openArmyManager.setVisible(false);
		}
	}
	
}