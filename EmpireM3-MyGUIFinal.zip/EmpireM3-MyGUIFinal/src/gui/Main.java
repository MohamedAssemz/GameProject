package gui;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

import engine.City;
import engine.Game;

public class Main {
	
	private static JFrame mainWindow;
	private static String currentView;
	
	public static void main(String[] args) {
		mainWindow = new JFrame();
		mainWindow.setTitle("The Conqueror");
		mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainWindow.setLayout(new BorderLayout());
		mainWindow.setResizable(false);
		mainWindow.setSize(1280, 720);
		mainWindow.add(new StartingPanel());
		mainWindow.setVisible(true);
	}
	public static void openMapView(Game game) {
		mainWindow.getContentPane().removeAll();
		mainWindow.add(new HeaderPanel(game, null), BorderLayout.NORTH);
		JPanel temp = new MapViewPanel(game);
		mainWindow.add(temp);
		currentView = "Map";
		mainWindow.validate();
		mainWindow.repaint();
	}
	public static void openCityManagerPanel(Game game, City city) {
		mainWindow.getContentPane().removeAll();
		mainWindow.add(new HeaderPanel(game, city), BorderLayout.NORTH);
		JPanel temp = new CityManagerPanel(game, city);
		mainWindow.add(temp);
		currentView = "City";
		mainWindow.validate();
		mainWindow.repaint();
	}
	public static void openBattlePanel(Game game, City city) {
		mainWindow.getContentPane().removeAll();
		mainWindow.add(new HeaderPanel(game, city), BorderLayout.NORTH);
		JPanel temp = new BattlePanel(game, city);
		mainWindow.add(temp);
		currentView = "Battle";
		mainWindow.validate();
		mainWindow.repaint();
	}
	
	public static void endGame() {
		mainWindow.setFocusable(false);
	}
	public static String getCurrentView() {
		return currentView;
	}
	public void setCurrentView(String currentView) {
		this.currentView = currentView;
	}
}
