package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import buildings.ArcheryRange;
import buildings.Barracks;
import buildings.Farm;
import buildings.Market;
import buildings.Stable;
import engine.City;
import engine.Game;
import exceptions.BuildingInCoolDownException;
import exceptions.MaxCapacityException;
import exceptions.MaxLevelException;
import exceptions.MaxRecruitedException;
import exceptions.NotEnoughGoldException;

public class CityManagerPanel extends JPanel implements ActionListener{
	private Game game;
	private City city;
	private JPanel armiesPanel;
	private JPanel buildingsPanel;
	private JButton[] upgradeButtons;
	private JButton build;
	private JButton[] recruitButtons;
	private JButton returnButton;
	private String[] buildOptions = {"Farm (1000g)", "Market (1500g)", "Archery Range (1500g)", "Barracks (2000g)", "Stable (2500g)"};

	public CityManagerPanel(Game game, City city) {
		this.city = city;
		this.game = game;
		this.setLayout(new BorderLayout());
		
		armiesPanel = new JPanel();
		armiesPanel.setBackground(Color.cyan);
		armiesPanel.setPreferredSize(new Dimension(640, this.getHeight()));
		this.add(armiesPanel, BorderLayout.EAST);
		
		buildingsPanel = new JPanel();
		buildingsPanel.setBackground(Color.yellow);
		this.add(buildingsPanel, BorderLayout.CENTER);
		
		/*-----------------------------------------------------------------------------*/
		
		JLabel cityBuildingsTitle = new JLabel(city.getName() + " Buildings");
		JLabel economicBuildingsTitle = new JLabel("Economic Buildings");
		JLabel militaryBuildingsTitle = new JLabel("Military Buildings");
		
		upgradeButtons = new JButton[5];
		recruitButtons = new JButton[3];
		if(city.getEconomicalBuildings().isEmpty() && city.getMilitaryBuildings().isEmpty()) {
			JLabel noBuildings = new JLabel ("You have no buildings. Build some!");
			buildingsPanel.add(noBuildings);
		}
		else {
			buildingsPanel.add(cityBuildingsTitle);
			buildingsPanel.add(economicBuildingsTitle);
			for(int i = 0; i < city.getEconomicalBuildings().size(); i++) {
				buildingsPanel.add(new BuildingInfoBox(city.getEconomicalBuildings().get(i), game));
				if(city.getEconomicalBuildings().get(i) instanceof Farm) {
					upgradeButtons[0] = new JButton("Upgrade Farm");
					upgradeButtons[0].addActionListener(this);
					buildingsPanel.add(upgradeButtons[0]);
				}
				if(city.getEconomicalBuildings().get(i) instanceof Market) {
					upgradeButtons[1] = new JButton("Upgrade Market");
					upgradeButtons[1].addActionListener(this);
					buildingsPanel.add(upgradeButtons[1]);
				}
			}
			buildingsPanel.add(militaryBuildingsTitle);
			for(int i = 0; i < city.getMilitaryBuildings().size(); i++) {
				buildingsPanel.add(new BuildingInfoBox(city.getMilitaryBuildings().get(i), game));
				if(city.getMilitaryBuildings().get(i) instanceof ArcheryRange) {
					upgradeButtons[2] = new JButton("Upgrade Archery Range");
					upgradeButtons[2].addActionListener(this);
					buildingsPanel.add(upgradeButtons[2]);
				}
				if(city.getMilitaryBuildings().get(i) instanceof Barracks) {
					upgradeButtons[3] = new JButton("Upgrade Barracks");
					upgradeButtons[3].addActionListener(this);
					buildingsPanel.add(upgradeButtons[3]);
				}
				if(city.getMilitaryBuildings().get(i) instanceof Stable) {
					upgradeButtons[4] = new JButton("Upgrade Stable");
					upgradeButtons[4].addActionListener(this);
					buildingsPanel.add(upgradeButtons[4]);
				}
				
				if(city.getMilitaryBuildings().get(i) instanceof ArcheryRange) {
					recruitButtons[0] = new JButton("Recruit Archer");
					recruitButtons[0].addActionListener(this);
					buildingsPanel.add(recruitButtons[0]);
				}
				if(city.getMilitaryBuildings().get(i) instanceof Barracks) {
					recruitButtons[1] = new JButton("Recruit Infantry");
					recruitButtons[1].addActionListener(this);
					buildingsPanel.add(recruitButtons[1]);
				}
				if(city.getMilitaryBuildings().get(i) instanceof Stable) {
					recruitButtons[2] = new JButton("Recruit Cavalry");
					recruitButtons[2].addActionListener(this);
					buildingsPanel.add(recruitButtons[2]);
				}
				
			}
		}
		
		build = new JButton("Build");
		build.addActionListener(this);
		buildingsPanel.add(build);
		
		/*-----------------------------------------------------------------------------*/
		
		JLabel armiesTitle = new JLabel(city.getName() + "'s Armies");
		armiesPanel.add(armiesTitle);
		JLabel defendingArmyTitle = new JLabel("Defending Army: " + city.getDefendingArmy().getName());
		armiesPanel.add(defendingArmyTitle);
		JLabel stationedArmiesTitle = new JLabel("Other Garrisoned Armies: ");
		
		ArmyInfoBox defenderInfo = new ArmyInfoBox(city.getDefendingArmy(), game);
		armiesPanel.add(defenderInfo);
		armiesPanel.add(stationedArmiesTitle);
		for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
			if(game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equals(city.getName()) && !game.getPlayer().getControlledArmies().get(i).equals(city.getDefendingArmy())) {
				armiesPanel.add(new ArmyInfoBox(game.getPlayer().getControlledArmies().get(i), game));
			}
		}
		
		returnButton = new JButton("Return to Map");
		returnButton.addActionListener(this);
		armiesPanel.add(returnButton);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(build)){
			String choice = (String) JOptionPane.showInputDialog(null, "What would you like to build?", "Build", JOptionPane.PLAIN_MESSAGE, null, buildOptions, "Farm");
			if(choice != null && choice.length() > 0) {
				if(choice.equals("Farm (1000g)")){
					for(int j = 0; j < this.city.getEconomicalBuildings().size(); j++) {
						if(this.city.getEconomicalBuildings().get(j) instanceof Farm) {
							JOptionPane.showMessageDialog(null, "Sorry, you can't build more than one of the same building.");
							return;
						}
					}
					try {
						game.getPlayer().build("Farm", city.getName());
						Main.openCityManagerPanel(game,city);
					} catch (NotEnoughGoldException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
					}
				}
				if(choice.equals("Market (1500g)")){
					for(int j = 0; j < this.city.getEconomicalBuildings().size(); j++) {
						if(this.city.getEconomicalBuildings().get(j) instanceof Market) {
							JOptionPane.showMessageDialog(null, "Sorry, you can't build more than one of the same building.");
							return;
						}
					}
					try {
						game.getPlayer().build("Market", city.getName());
						Main.openCityManagerPanel(game,city);
					} catch (NotEnoughGoldException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
					}
				}
				if(choice.equals("Archery Range (1500g)")){
					for(int j = 0; j < this.city.getMilitaryBuildings().size(); j++) {
						if(this.city.getMilitaryBuildings().get(j) instanceof ArcheryRange) {
							JOptionPane.showMessageDialog(null, "Sorry, you can't build more than one of the same building.");
							return;
						}
					}
					try {
						game.getPlayer().build("ArcheryRange", city.getName());
						Main.openCityManagerPanel(game,city);
					} catch (NotEnoughGoldException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
					}
				}
				if(choice.equals("Barracks (2000g)")){
					for(int j = 0; j < this.city.getMilitaryBuildings().size(); j++) {
						if(this.city.getMilitaryBuildings().get(j) instanceof Barracks) {
							JOptionPane.showMessageDialog(null, "Sorry, you can't build more than one of the same building.");
							return;
						}
					}
					try {
						game.getPlayer().build("Barracks", city.getName());
						Main.openCityManagerPanel(game,city);
					} catch (NotEnoughGoldException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
					}
				}
				if(choice.equals("Stable (2500g)")){
					for(int j = 0; j < this.city.getMilitaryBuildings().size(); j++) {
						if(this.city.getMilitaryBuildings().get(j) instanceof Stable) {
							JOptionPane.showMessageDialog(null, "Sorry, you can't build more than one of the same building.");
							return;
						}
					}
					try {
						game.getPlayer().build("Stable", city.getName());
						Main.openCityManagerPanel(game,city);
					} catch (NotEnoughGoldException e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
					}
				}
			}
		}
		 if(e.getSource() == recruitButtons[0]) {
    		 if(city.getDefendingArmy().getUnits().size() < city.getDefendingArmy().getMaxToHold()) {
    			 try {
    					game.getPlayer().recruitUnit("Archer", city.getName());
    					Main.openCityManagerPanel(game,city);
    				} catch (BuildingInCoolDownException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, that building is cooling down.");
    					e1.printStackTrace();
    				} catch (MaxRecruitedException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, you've recrutied too many units from that building already.");
    					e1.printStackTrace();
    				} catch (NotEnoughGoldException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
    					e1.printStackTrace();
    				}
    		 }
    		 else {
    			 JOptionPane.showMessageDialog(null, "Sorry, the defending army is at max capacity. Move some units out if you still want to recruit.");
    		 }
    	 }
    	 if(e.getSource() == recruitButtons[1]) {
    		 if(city.getDefendingArmy().getUnits().size() < city.getDefendingArmy().getMaxToHold()) {
    			 try {
    					game.getPlayer().recruitUnit("Infantry", city.getName());
    					Main.openCityManagerPanel(game,city);
    				} catch (BuildingInCoolDownException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, that building is cooling down.");
    					e1.printStackTrace();
    				} catch (MaxRecruitedException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, you've recrutied too many units from that building already.");
    					e1.printStackTrace();
    				} catch (NotEnoughGoldException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
    					e1.printStackTrace();
    				}
    		 }
    		 else {
    			 JOptionPane.showMessageDialog(null, "Sorry, the defending army is at max capacity. Move some units out if you still want to recruit.");
    		 }
    	 }
    	 if(e.getSource() == recruitButtons[2]) {
    		 if(city.getDefendingArmy().getUnits().size() < city.getDefendingArmy().getMaxToHold()) {
    			 try {
    					game.getPlayer().recruitUnit("Cavalry", city.getName());
    					Main.openCityManagerPanel(game,city);
    				} catch (BuildingInCoolDownException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, that building is cooling down.");
    					e1.printStackTrace();
    				} catch (MaxRecruitedException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, you've recrutied too many units from that building already.");
    					e1.printStackTrace();
    				} catch (NotEnoughGoldException e1) {
    					// TODO Auto-generated catch block
    					JOptionPane.showMessageDialog(null, "Sorry, you don't have enough gold for that.");
    					e1.printStackTrace();
    				}
    		 }
    		 else {
    			 JOptionPane.showMessageDialog(null, "Sorry, the defending army is at max capacity. Move some units out if you still want to recruit.");
    		 }
    	 }
		if(e.getSource() == upgradeButtons[0]) {
			for(int i = 0; i < city.getEconomicalBuildings().size(); i++) {
				if(city.getEconomicalBuildings().get(i) instanceof Farm) {
					try {
						game.getPlayer().upgradeBuilding(city.getEconomicalBuildings().get(i));
						Main.openCityManagerPanel(game,city);
					}  catch (NotEnoughGoldException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you don't have enough gold for that.");

					} catch (BuildingInCoolDownException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, that building is cooling down.");

					} catch (MaxLevelException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you can't upgrade past this level.");

					}
				}
			}
		}
		if(e.getSource() == upgradeButtons[1]) {
			for(int i = 0; i < city.getEconomicalBuildings().size(); i++) {
				if(city.getEconomicalBuildings().get(i) instanceof Market) {
					try {
						game.getPlayer().upgradeBuilding(city.getEconomicalBuildings().get(i));
						Main.openCityManagerPanel(game,city);
					}  catch (NotEnoughGoldException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you don't have enough gold for that.");

					} catch (BuildingInCoolDownException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, that building is cooling down.");

					} catch (MaxLevelException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you can't upgrade past this level.");

					}
				}
			}
		}
		if(e.getSource() == upgradeButtons[2]) {
			for(int i = 0; i < city.getMilitaryBuildings().size(); i++) {
				if(city.getMilitaryBuildings().get(i) instanceof ArcheryRange) {
					try {
						game.getPlayer().upgradeBuilding(city.getMilitaryBuildings().get(i));
						Main.openCityManagerPanel(game,city);
					}  catch (NotEnoughGoldException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you don't have enough gold for that.");

					} catch (BuildingInCoolDownException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, that building is cooling down.");

					} catch (MaxLevelException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you can't upgrade past this level.");

					}
				}
			}
		}
		if(e.getSource() == upgradeButtons[3]) {
			for(int i = 0; i < city.getMilitaryBuildings().size(); i++) {
				if(city.getMilitaryBuildings().get(i) instanceof Barracks) {
					try {
						game.getPlayer().upgradeBuilding(city.getMilitaryBuildings().get(i));
						Main.openCityManagerPanel(game,city);
					}  catch (NotEnoughGoldException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you don't have enough gold for that.");

					} catch (BuildingInCoolDownException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, that building is cooling down.");

					} catch (MaxLevelException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you can't upgrade past this level.");

					}
				}
			}
		}
		if(e.getSource() == upgradeButtons[4]) {
			for(int i = 0; i < city.getMilitaryBuildings().size(); i++) {
				if(city.getMilitaryBuildings().get(i) instanceof Stable) {
					try {
						game.getPlayer().upgradeBuilding(city.getMilitaryBuildings().get(i));
						Main.openCityManagerPanel(game,city);
					}  catch (NotEnoughGoldException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you don't have enough gold for that.");

					} catch (BuildingInCoolDownException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, that building is cooling down.");

					} catch (MaxLevelException e1) {
						JOptionPane.showMessageDialog(this, "Sorry, you can't upgrade past this level.");

					}
				}
			}
		}

		if(e.getSource() == returnButton) {
			Main.openMapView(game);
		}
	}
}
