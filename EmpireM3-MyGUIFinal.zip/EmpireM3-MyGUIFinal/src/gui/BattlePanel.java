package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import engine.City;
import engine.Game;
import exceptions.FriendlyCityException;
import exceptions.FriendlyFireException;
import exceptions.MaxCapacityException;
import exceptions.TargetNotReachedException;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Unit;

public class BattlePanel extends JPanel implements ActionListener{
	private City city;
	private Game game;
	private JPanel attackingArmies;
	private JPanel defendingArmies;
	private JPanel battleLog;
	private JButton takeAction;
	private JButton returnButton;
	private ArrayList<Army> attackingArmiesList;
	
	public BattlePanel(Game game, City city) {
		this.city = city;
		this.game = game;
		this.setLayout(new BorderLayout());
		
		attackingArmies = new JPanel();
		attackingArmies.setBackground(Color.cyan);
		attackingArmies.setPreferredSize(new Dimension(640, this.getHeight()));
		this.add(attackingArmies, BorderLayout.EAST);
		
		defendingArmies = new JPanel();
		defendingArmies.setBackground(Color.yellow);
		this.add(defendingArmies, BorderLayout.CENTER);
		
		battleLog = new JPanel();
		battleLog.setBackground(Color.orange);
		battleLog.setLayout(new BorderLayout());
		battleLog.setPreferredSize(new Dimension(this.getWidth(), 120));
		this.add(battleLog, BorderLayout.SOUTH);
		
		/*--------------------------------------*/
		
		JLabel cityTitle = new JLabel(city.getName());
		defendingArmies.add(cityTitle);
		
		JLabel defendingArmiesTitle = new JLabel("The Army Defending " + city.getName());
		defendingArmies.add(defendingArmiesTitle);
		
		ArmyInfoBox defendingArmyInfo = new ArmyInfoBox(city.getDefendingArmy(), game);
		defendingArmies.add(defendingArmyInfo);
		
		/*--------------------------------------*/
			
		JLabel attackingArmiesTitle = new JLabel("The Armies Attacking " + city.getName());
		attackingArmies.add(attackingArmiesTitle);
		
		attackingArmiesList = new ArrayList<Army>();
		for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
			if(game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equals(city.getName())) {
				attackingArmiesList.add(game.getPlayer().getControlledArmies().get(i));
			}
		}
		for(int i = 0; i < attackingArmiesList.size(); i++) {
			attackingArmies.add(new ArmyInfoBox(attackingArmiesList.get(i), game));
		}

		takeAction = new JButton("Take Action");
		takeAction.addActionListener(this);
		attackingArmies.add(takeAction);
		
		returnButton = new JButton("Return to Map");
		returnButton.addActionListener(this);
		attackingArmies.add(returnButton);
		
		/*--------------------------------------*/
		JLabel battleLogTitle = new JLabel("Battle Log");
		battleLog.add(battleLogTitle);
		
		JTextArea battleLogArea = new JTextArea(game.getGameLog());
		battleLogArea.setSize(new Dimension(1000, 100));
		battleLogArea.setLineWrap(false);
		battleLogArea.setVisible(true);
		
		JScrollPane battleLogScroll = new JScrollPane(battleLogArea);
		battleLogScroll.setPreferredSize(new Dimension(1000, 100));
		battleLogScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		battleLogScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		
		battleLog.add(battleLogScroll, BorderLayout.CENTER);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == takeAction) {
			String[] options = {"Besiege", "Attack a Defending Unit", "Attack the Defending Army"};
			ArrayList<String> armyNamesAL = new ArrayList<String>();
			for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
				if(game.getPlayer().getControlledArmies().get(i).getCurrentLocation().equals(city.getName())) {
					armyNamesAL.add(game.getPlayer().getControlledArmies().get(i).getName());
				}
			}
			String[] armyNames = new String[armyNamesAL.size()];
			for(int i = 0; i < armyNamesAL.size(); i++) {
				armyNames[i] = armyNamesAL.get(i);
			}
			String choice = (String) JOptionPane.showInputDialog(null, "What would you like to do?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, options, "Besiege");
			if(choice.equals("Besiege")) {
				String besiegingArmyS = (String) JOptionPane.showInputDialog(null, "Which army would you like to lay siege with?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				Army besiegingArmyA = null;
				for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
					if(besiegingArmyS.equals(game.getPlayer().getControlledArmies().get(i).getName())) {
						besiegingArmyA = game.getPlayer().getControlledArmies().get(i);
					}
				}
				if(city.getTurnsUnderSiege() >= 3) {
					JOptionPane.showMessageDialog(null, "Sorry, you can't lay siege. This city's already been besieged for too long.");
				}
				else {
					try {
						game.getPlayer().laySiege(besiegingArmyA, city);
						Main.openBattlePanel(game, city);
					} catch (TargetNotReachedException e1) {
						JOptionPane.showMessageDialog(null, "Sorry, can't lay siege unless you're at the city you want to besiege.");
						e1.printStackTrace();
					} catch (FriendlyCityException e1) {
						JOptionPane.showMessageDialog(null, "Sorry, can't lay siege to your own city.");
						e1.printStackTrace();
					}
				}
			}
			
			if(choice.equals("Attack a Defending Unit")) {
				String armySourceS = (String) JOptionPane.showInputDialog(null, "Which army is the unit you will attack with in?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				Army armySourceA = null;
				Unit attackingUnit = null;
				for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
					if(armySourceS.equals(game.getPlayer().getControlledArmies().get(i).getName())){
						armySourceA = game.getPlayer().getControlledArmies().get(i);
					}
				}
				String[] armySUnitsNames = new String[armySourceA.getUnits().size()];
				Unit[] armySUnits = new Unit[armySourceA.getUnits().size()]; 
				armySourceA.organize();
				for(int i = 0; i < armySourceA.getUnits().size(); i++) {
					Unit u = armySourceA.getUnits().get(i);
					armySUnits[i] = u;
					if(u instanceof Archer) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Archer" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers";
					}
					if(u instanceof Infantry) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Infantry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers";
					}
					if(u instanceof Cavalry) {
						armySUnitsNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Cavalry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers";
					}
				}
				String attackingUnitName = (String) JOptionPane.showInputDialog(null, "Which unit do you want to attack with?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armySUnitsNames, armySUnitsNames[0]);
				attackingUnit = armySUnits[Integer.parseInt(attackingUnitName.charAt(0)+ "") - 1];
				String[] defendingArmyUnitNames = new String[city.getDefendingArmy().getUnits().size()];
				Unit[] defendingArmyUnits = new Unit[city.getDefendingArmy().getUnits().size()];
				city.getDefendingArmy().organize();
				for(int i = 0; i < city.getDefendingArmy().getUnits().size(); i++) {
					Unit u = city.getDefendingArmy().getUnits().get(i);
					defendingArmyUnits[i] = u;
					if(u instanceof Archer) {
						defendingArmyUnitNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Archer" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers";
					}
					if(u instanceof Infantry) {
						defendingArmyUnitNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Infantry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers";
					}
					if(u instanceof Cavalry) {
						defendingArmyUnitNames[i] = (i+1) + "- Level " + u.getLevel() + " " + "Cavalry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers";
					}
				}
				String attackedUnitName = (String) JOptionPane.showInputDialog(null, "Which unit do you want to attack?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, defendingArmyUnitNames, defendingArmyUnitNames[0]);
				Unit attackedUnit = defendingArmyUnits[Integer.parseInt(attackedUnitName.charAt(0)+ "") - 1];
				
				try {
					attackingUnit.attack(attackedUnit);
					armySourceA.handleAttackedUnit(attackingUnit);
					city.getDefendingArmy().handleAttackedUnit(attackedUnit);
					game.setGameLog(game.getGameLog() + attackingUnitName + " from " + armySourceS + " attacked " + attackedUnitName + " from " + city.getDefendingArmy().getName());
					if(attackedUnit.getCurrentSoldierCount() > 0) {
						game.setGameLog(game.getGameLog() + " and reduced them to " + attackedUnit.getCurrentSoldierCount() + "\n");
					}
					else {
						game.setGameLog(game.getGameLog() + " and killed them! \n");
					}
					game.endTurn();
					/*--------------------------------------------*/
					int b = 0;
					if(city.getDefendingArmy().getUnits().size() > 1) {
						b = (int) (city.getDefendingArmy().getUnits().size() * java.lang.Math.random());
					}
					city.getDefendingArmy().getUnits().get(b).attack(attackingUnit);
					
					String otherUnitName = "";
					if(city.getDefendingArmy().getUnits().get(b) instanceof Archer) {
						otherUnitName = "Level " + city.getDefendingArmy().getUnits().get(b).getLevel() + " " + "Archer" + " | " + city.getDefendingArmy().getUnits().get(b).getCurrentSoldierCount() + "/" + city.getDefendingArmy().getUnits().get(b).getMaxSoldierCount() + " Soldiers";
					}
					if(city.getDefendingArmy().getUnits().get(b) instanceof Infantry) {
						otherUnitName = "Level " + city.getDefendingArmy().getUnits().get(b).getLevel() + " " + "Infantry" + " | " + city.getDefendingArmy().getUnits().get(b).getCurrentSoldierCount() + "/" + city.getDefendingArmy().getUnits().get(b).getMaxSoldierCount() + " Soldiers";
					}
					if(city.getDefendingArmy().getUnits().get(b) instanceof Cavalry) {
						otherUnitName = "Level " + city.getDefendingArmy().getUnits().get(b).getLevel() + " " + "Cavalry" + " | " + city.getDefendingArmy().getUnits().get(b).getCurrentSoldierCount() + "/" + city.getDefendingArmy().getUnits().get(b).getMaxSoldierCount() + " Soldiers";
					}
					
					armySourceA.handleAttackedUnit(attackingUnit);
					city.getDefendingArmy().handleAttackedUnit(city.getDefendingArmy().getUnits().get(b));
					game.setGameLog(game.getGameLog() + otherUnitName + " from " + city.getDefendingArmy().getName() + " attacked " + attackingUnitName + " from " + city.getDefendingArmy().getName());
					if(attackingUnit.getCurrentSoldierCount() > 0) {
						game.setGameLog(game.getGameLog() + " and reduced them to " + attackingUnit.getCurrentSoldierCount() + "\n");
					}
					else {
						game.setGameLog(game.getGameLog() + " and killed them! \n");
					}
					/*--------------------------------------------*/
					Main.openBattlePanel(game, city);
				} catch (FriendlyFireException e1) {
					JOptionPane.showMessageDialog(null, "Don't attack your own units!");
					e1.printStackTrace();
				}
			}
			
			if(choice.equals("Attack the Defending Army")) {
				String armySourceS = (String) JOptionPane.showInputDialog(null, "Which army will you attack with?", "Army Manager", JOptionPane.PLAIN_MESSAGE, null, armyNames, armyNames[0]);
				Army armySourceA = null;
				for(int i = 0; i < game.getPlayer().getControlledArmies().size(); i++) {
					if(armySourceS.equals(game.getPlayer().getControlledArmies().get(i).getName())){
						armySourceA = game.getPlayer().getControlledArmies().get(i);
					}
				}
				try {
					game.autoResolve(armySourceA, city.getDefendingArmy());
					Main.openMapView(game);
				} catch (FriendlyFireException e1) {
					JOptionPane.showMessageDialog(null, "Don't attack your own city!");
					e1.printStackTrace();
				}
			}
		}
		
		if(e.getSource() == returnButton) {
			Main.openMapView(game);
		}
	}
}
