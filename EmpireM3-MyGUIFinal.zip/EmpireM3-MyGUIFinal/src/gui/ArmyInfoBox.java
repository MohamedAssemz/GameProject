package gui;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import engine.Game;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Status;
import units.Unit;

public class ArmyInfoBox extends JTextArea {
	public ArmyInfoBox(Army a, Game game) {
		String armyInfoText = "Name: " + a.getName() + "\n";
		if(a.getCurrentStatus().equals(Status.IDLE)) {
			armyInfoText += "Status: Idle \n";
			armyInfoText += "Current Location: " + a.getCurrentLocation() + "\n";
			if(a.getTarget().equals("")) {
				armyInfoText += "Target: None \n";
			}
			else {
				armyInfoText += "Target: " + a.getTarget() + "\n";
			}
		}
		if(a.getCurrentStatus().equals(Status.MARCHING)) {
			armyInfoText += "Status: Marching \n";
			armyInfoText += "Current Location: Travelling to " + a.getTarget() + "\n"; 
			armyInfoText += "Target: " + a.getTarget() + "\n";
			armyInfoText += "Turns until arrival: " + a.getDistancetoTarget() + "\n";
		}
		if(a.getCurrentStatus().equals(Status.BESIEGING)) {
			armyInfoText += "Status: Besieging \n";
			armyInfoText += "Current Location: " + a.getCurrentLocation() + "\n"; 
			armyInfoText += "Target: " + a.getTarget() + "\n";
			int turnsBesieging = 0;
			for(int i = 0; i < game.getAvailableCities().size(); i++) {
				if(a.getCurrentLocation().equals(game.getAvailableCities().get(i).getName())) {
					turnsBesieging = game.getAvailableCities().get(i).getTurnsUnderSiege();
				}
			}
			armyInfoText += "Turns besieging: " + turnsBesieging + "\n";
		}
		a.organize();
		
		if(a.getUnits().isEmpty()) {
			armyInfoText += "Units: No one's here. Better recruit some units!";
		}
		else {
			armyInfoText += "Units: \n";
			for(int i = 0; i < a.getUnits().size(); i++) {
				Unit u = a.getUnits().get(i);
				if(u instanceof Archer) {
					armyInfoText += (i+1) + "- Level " + u.getLevel() + " " + "Archer" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
				}
				if(u instanceof Infantry) {
					armyInfoText += (i+1) + "- Level " + u.getLevel() + " " + "Infantry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
				}
				if(u instanceof Cavalry) {
					armyInfoText += (i+1) + "- Level " + u.getLevel() + " " + "Cavalry" + " | " + u.getCurrentSoldierCount() + "/" + u.getMaxSoldierCount() + " Soldiers \n";
				}
				
			}
		}
		
		
		
		this.setText(armyInfoText);
		this.setWrapStyleWord(true);
		this.setEditable(false);
		new JScrollPane(this, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);	//from StackOverflaw
	}
}
