package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import engine.City;
import engine.Game;

public class HeaderPanel extends JPanel implements ActionListener{
	private JButton endTurn;
	private Game game;
	private City city;

	public HeaderPanel(Game game, City city) {
		this.game = game;
		this.city = city;
		this.setBackground(Color.red);
		this.setPreferredSize(new Dimension(1280, 40));
		
		JLabel name = new JLabel();
		name.setText("Name: Lord " + game.getPlayer().getName() + " the Great");
		this.add(name);
		
		JLabel treasury = new JLabel();
		treasury.setText("Gold: " + game.getPlayer().getTreasury());
		this.add(treasury);
		
		JLabel food = new JLabel();
		food.setText("Food: " + game.getPlayer().getFood());
		this.add(food);
		
		JLabel turn = new JLabel();
		turn.setText("Turn: " + game.getCurrentTurnCount());
		this.add(turn);
		
		endTurn = new JButton("End Turn");
		endTurn.addActionListener(this);
		this.add(endTurn);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == endTurn) {
			if(game.getCurrentTurnCount() < 50) {
			game.endTurn();
			if(Main.getCurrentView().equals("Map")) {
				Main.openMapView(game);
			}
			if(Main.getCurrentView().equals("City")) {
				Main.openCityManagerPanel(game, city);
			}
			if(Main.getCurrentView().equals("Battle")) {
				Main.openBattlePanel(game, city);
			}
		}
			else {
				endTurn.setVisible(false);
				
			}
		}
	}
}
