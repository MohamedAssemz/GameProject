package gui;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import buildings.ArcheryRange;
import buildings.Barracks;
import buildings.Building;
import buildings.EconomicBuilding;
import buildings.Farm;
import buildings.Market;
import buildings.MilitaryBuilding;
import buildings.Stable;
import engine.Game;
import units.Army;
import units.Status;
import units.Unit;

public class BuildingInfoBox extends JTextArea {
	public BuildingInfoBox(Building b, Game game) {
		String buildingInfoText = "";
		if(b instanceof Market) {
			buildingInfoText = "Name: Market \n Level: " + b.getLevel() + "\n" + "Gold per turn: " + ((Market) b).harvest() + "\n";
		}
		if(b instanceof Farm) {
			buildingInfoText = "Name: Farm \n Level: " + b.getLevel() + "\n" + "Food per turn: " + ((Farm) b).harvest() + "\n";
		}
		if(b instanceof ArcheryRange) {
			buildingInfoText = "Name: Archery Range \nLevel: " + b.getLevel() + "\n";
		}
		if(b instanceof Barracks) {
			buildingInfoText = "Name: Barracks \nLevel: " + b.getLevel() + "\n";
		}
		if(b instanceof Stable) {
			buildingInfoText = "Name: Stable \nLevel: " + b.getLevel() + "\n";
		}
		buildingInfoText += "Upgrade Cost: " + b.getUpgradeCost() + "\n";
		if(b instanceof MilitaryBuilding) {
			buildingInfoText += "Recruitment Cost: " + ((MilitaryBuilding) b).getRecruitmentCost() + "\n";
			Unit u = ((MilitaryBuilding) b).couldRecruit();
			if(b instanceof ArcheryRange) {
				buildingInfoText += "Output Unit: " + "Level " + u.getLevel() + " " + "Archer" + " with " + u.getMaxSoldierCount() + " Soldiers \n"; 
			}
			if(b instanceof Barracks) {
				buildingInfoText += "Output Unit: " + "Level " + u.getLevel() + " " + "Infantry" + " with " + u.getMaxSoldierCount() + " Soldiers \n"; 
			}
			if(b instanceof Stable) {
				buildingInfoText += "Output Unit: " + "Level " + u.getLevel() + " " + "Cavalry" + " with " + u.getMaxSoldierCount() + " Soldiers \n"; 
			}
		}
		buildingInfoText += "On Cooldown: " + b.isCoolDown();
		this.setText(buildingInfoText);
		this.setWrapStyleWord(true);
		this.setEditable(false);
		new JScrollPane(this, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);	//from StackOverflaw
	}
}
