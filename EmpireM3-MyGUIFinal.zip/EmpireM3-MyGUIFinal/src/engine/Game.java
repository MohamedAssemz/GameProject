package engine;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import buildings.Farm;
import exceptions.FriendlyFireException;
import gui.Main;
import units.Archer;
import units.Army;
import units.Cavalry;
import units.Infantry;
import units.Status;
import units.Unit;

public class Game {
	private Player player;
	private ArrayList<City> availableCities;
	private ArrayList<Distance> distances;
	private final int maxTurnCount = 50;
	private int currentTurnCount;
	private String gameLog = "";

	public Game(String playerName, String playerCity) throws IOException {

		player = new Player(playerName);
		availableCities = new ArrayList<City>();
		distances = new ArrayList<Distance>();
		currentTurnCount = 1;
		loadCitiesAndDistances();
		for (City c : availableCities) {
			if (c.getName().equals(playerCity)) {
				player.getControlledCities().add(c);
				player.getControlledArmies().add(c.getDefendingArmy());
			}
			else {
				loadArmy(c.getName(), c.getName().toLowerCase() + "_army.csv");
			}
		}
		setGameLog(getGameLog() + "Started 'The Conqueror' as " + player.getName() + " in " + player.getControlledCities().get(0).getName() + "\n");
	}

	private void loadCitiesAndDistances() throws IOException {

		BufferedReader br = new BufferedReader(new FileReader("distances.csv"));
		String currentLine = br.readLine();
		ArrayList<String> names = new ArrayList<String>();

		while (currentLine != null) {

			String[] content = currentLine.split(",");
			if (!names.contains(content[0])) {
				availableCities.add(new City(content[0]));
				names.add(content[0]);
			} else if (!names.contains(content[1])) {
				availableCities.add(new City(content[1]));
				names.add(content[1]);
			}
			distances.add(new Distance(content[0], content[1], Integer.parseInt(content[2])));
			currentLine = br.readLine();

		}
		br.close();
	}

	public void loadArmy(String cityName, String path) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(path));
		String currentLine = br.readLine();
		Army resultArmy = new Army(cityName, "Army of " + cityName);
		while (currentLine != null) {
			String[] content = currentLine.split(",");
			String unitType = content[0].toLowerCase();
			int unitLevel = Integer.parseInt(content[1]);
			Unit u = null;
			if (unitType.equals("archer")) {

				if (unitLevel == 1)
					u = (new Archer(1, 60, 0.4, 0.5, 0.6));

				else if (unitLevel == 2)
					u = (new Archer(2, 60, 0.4, 0.5, 0.6));
				else
					u = (new Archer(3, 70, 0.5, 0.6, 0.7));
			} else if (unitType.equals("infantry")) {
				if (unitLevel == 1)
					u = (new Infantry(1, 50, 0.5, 0.6, 0.7));

				else if (unitLevel == 2)
					u = (new Infantry(2, 50, 0.5, 0.6, 0.7));
				else
					u = (new Infantry(3, 60, 0.6, 0.7, 0.8));
			} else if (unitType.equals("cavalry")) {
				if (unitLevel == 1)
					u = (new Cavalry(1, 40, 0.6, 0.7, 0.75));

				else if (unitLevel == 2)
					u = (new Cavalry(2, 40, 0.6, 0.7, 0.75));
				else
					u = (new Cavalry(3, 60, 0.7, 0.8, 0.9));
			}
			resultArmy.getUnits().add(u);
			u.setParentArmy(resultArmy);
			currentLine = br.readLine();
		}
		br.close();
		for (City c : availableCities) {
			if (c.getName().toLowerCase().equals(cityName.toLowerCase()))
				c.setDefendingArmy(resultArmy);
		}
	}

	public ArrayList<City> getAvailableCities() {
		return availableCities;
	}

	public ArrayList<Distance> getDistances() {
		return distances;
	}

	public int getCurrentTurnCount() {
		return currentTurnCount;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public int getMaxTurnCount() {
		return maxTurnCount;
	}

	public void setCurrentTurnCount(int currentTurnCount) {
		this.currentTurnCount = currentTurnCount;
	}
	
	public void targetCity(Army army, String targetName) {
		String home = army.getCurrentLocation();
		if(army.getCurrentStatus().equals(Status.IDLE) || army.getCurrentStatus().equals(Status.BESIEGING)) {
			for(int i = 0; i < this.distances.size(); i++) {
				if((this.distances.get(i).getFrom().equals(home) && this.distances.get(i).getTo().equals(targetName)) ||
					(this.distances.get(i).getTo().equals(home) && this.distances.get(i).getFrom().equals(targetName))) {
					army.setDistancetoTarget(this.distances.get(i).getDistance());
					army.setTarget(targetName);
				}
			}
		}
		else if (army.getCurrentStatus().equals(Status.MARCHING)) {
			for(int i = 0; i < this.distances.size(); i++) {
				if((this.distances.get(i).getFrom().equals(army.getTarget()) && this.distances.get(i).getTo().equals(targetName)) ||
					(this.distances.get(i).getTo().equals(army.getTarget()) && this.distances.get(i).getFrom().equals(targetName))) {
					army.setDistancetoTarget(this.distances.get(i).getDistance() + army.getDistancetoTarget());
					army.setTarget(targetName);
				}
			}
		}
	}
	
	public void occupy(Army a, String cityName) {
		for(int i =0; i < this.availableCities.size(); i++) {
			City c = this.availableCities.get(i);
			if(this.availableCities.get(i).getName().equals(cityName)) {
				this.player.getControlledCities().add(c);
				c.setUnderSiege(false);
				c.setTurnsUnderSiege(0);
				break;
			}
		}
		setGameLog(getGameLog() + "You've occupied " + cityName + "! \n");
	}
	
	public void autoResolve(Army attacker, Army defender) throws FriendlyFireException{
		Boolean flag = true;
		while(attacker.getUnits().size() > 0 && defender.getUnits().size() > 0) {
			if(flag) {
				int a = 0;
				if(attacker.getUnits().size() > 1) {
					a = (int) (attacker.getUnits().size() * java.lang.Math.random());
				}
				int b = 0;
				if(defender.getUnits().size() > 1) {
					b = (int) (defender.getUnits().size() * java.lang.Math.random());
				}
				Unit temp = defender.getUnits().get(b);
				attacker.getUnits().get(a).attack(defender.getUnits().get(b));
				attacker.handleAttackedUnit(attacker.getUnits().get(a));
				defender.handleAttackedUnit(defender.getUnits().get(b));
				endTurn();
				flag = false;
				setGameLog(getGameLog() + attacker.getUnits().get(a) + " from " + attacker.getName()+ " attacked " + defender.getUnits().get(b) + " from " + defender.getName());
				if(defender.getUnits().contains(temp)) {
					setGameLog(getGameLog() + " and reduced them to " + temp.getCurrentSoldierCount() + "\n");
				}
				else {
					setGameLog(getGameLog() + " and killed them! \n");
				}
			}
			else {
				int a = 0;
				if(attacker.getUnits().size() > 1) {
					a = (int) (attacker.getUnits().size() * java.lang.Math.random());
				}
				int b = 0;
				if(defender.getUnits().size() > 1) {
					b = (int) (defender.getUnits().size() * java.lang.Math.random());
				}
				Unit temp = attacker.getUnits().get(a);
				defender.getUnits().get(b).attack(attacker.getUnits().get(a));
				attacker.handleAttackedUnit(attacker.getUnits().get(a));
				defender.handleAttackedUnit(defender.getUnits().get(b));
				endTurn();
				flag = false;
				setGameLog(getGameLog() + defender.getUnits().get(b) + " from " + defender.getName() +  " attacked " + attacker.getUnits().get(a) + " from " + attacker.getName());
				if(defender.getUnits().contains(temp)) {
					setGameLog(getGameLog() + " and reduced them to " + temp.getCurrentSoldierCount() + "\n");
				}
				else {
					setGameLog(getGameLog() + " and killed them! \n");
				}
			}
			
		}
		if(attacker.getUnits().size() > 0) {
			setGameLog(getGameLog() + attacker.getName() + " has defeated " + defender.getName() + "! \n");
			this.occupy(attacker, defender.getCurrentLocation());
		}
		else {
			setGameLog(getGameLog() + defender.getName() + " has defeated " + attacker.getName() + ". \n");
		}
	}
	
	public Boolean isGameOver() {
		if(this.player.getControlledCities().size() == this.availableCities.size() || this.currentTurnCount >= this.maxTurnCount) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public Boolean won() {
		if(this.player.getControlledCities().size() == this.availableCities.size()) {
			setGameLog(getGameLog() + this.player.getName() + " has conquered the world!");
			return true;
		}
		else {
			return false;
		}
	}
	
	public void endTurn() {
		this.currentTurnCount++;
		for(int i = 0; i < player.getControlledCities().size(); i++){
			City c = player.getControlledCities().get(i);
			for(int j = 0; j < c.getMilitaryBuildings().size(); j++) {
				c.getMilitaryBuildings().get(j).setCoolDown(false);
				c.getMilitaryBuildings().get(j).setCurrentRecruit(0);
			}
			for(int j = 0; j < c.getEconomicalBuildings().size(); j++) {
				c.getEconomicalBuildings().get(j).setCoolDown(false);
				if(c.getEconomicalBuildings().get(j) instanceof Farm) {
					player.setFood(c.getEconomicalBuildings().get(j).harvest() + player.getFood());
				}
				else {
					player.setTreasury(c.getEconomicalBuildings().get(j).harvest() + player.getTreasury());
				}
			}
		}
		for(int i = 0; i < player.getControlledArmies().size(); i++) {
			Army a = player.getControlledArmies().get(i);
			if(a.getCurrentStatus().equals(Status.MARCHING)) {
				if(a.getDistancetoTarget() > 0) {
					a.setDistancetoTarget(a.getDistancetoTarget() - 1);
				}
				if(a.getDistancetoTarget() == 0) {
					a.setCurrentLocation(a.getTarget());
					a.setCurrentStatus(Status.IDLE);
				}
			}
			player.setFood(player.getFood() - a.foodNeeded());
		}
		if(player.getFood() < 0) {
			player.setFood(0);
			for(int i = 0; i < player.getControlledArmies().size(); i++) {
				Army a = player.getControlledArmies().get(i);
				for(int j = 0; j < a.getUnits().size(); j++) {
					a.getUnits().get(j).setCurrentSoldierCount((int) (a.getUnits().get(j).getCurrentSoldierCount() * 0.9));
				}
			}
			setGameLog(getGameLog() + "You're out of food! All your units lose 10% of their soldiers. \n");
		}
		for(int i = 0; i < player.getControlledArmies().size(); i++) {
			Army a = player.getControlledArmies().get(i);
			for(int j = 0; j < a.getUnits().size(); j++) {
				if(a.getUnits().get(j).getCurrentSoldierCount() <= 0) {
					Unit u = a.getUnits().get(j);
					a.getUnits().remove(j);
					if(u instanceof Archer) {
						setGameLog(getGameLog() + "Level " + u.getLevel() + " " + "Archer");
					}
					if(u instanceof Infantry) {
						setGameLog(getGameLog() + "Level " + u.getLevel() + " " + "Infantry");
					}
					if(u instanceof Cavalry) {
						setGameLog(getGameLog() + "Level " + u.getLevel() + " " + "Cavalry");
					}
					setGameLog(getGameLog() + " has died. \n");
				}
			}
			Boolean removeArmy = false;
			if(a.getUnits().isEmpty()) {
				removeArmy = true;
				for(int j = 0; j < this.availableCities.size(); j++) {
					if(this.availableCities.get(j).getDefendingArmy().equals(a)) {
						removeArmy = false;
					}
				}
			}
			if(a.getCurrentStatus() == Status.BESIEGING) {
				for(int j = 0; j < this.availableCities.size(); j++) {
					if(a.getCurrentLocation().equals(this.availableCities.get(j).getName()) && this.availableCities.get(j).getTurnsUnderSiege() >= 3) {
						a.setCurrentStatus(Status.IDLE);
					}
				}
			}
			if(removeArmy) {
				this.player.getControlledArmies().remove(a);
				setGameLog(getGameLog() + a.getName() + " has been obliterated. \n");
			}
		}
		for(int i = 0; i < this.getAvailableCities().size(); i++) {
			Army a = this.getAvailableCities().get(i).getDefendingArmy();
			for(int j = 0; j < a.getUnits().size(); j++) {
				if(a.getUnits().get(j).getCurrentSoldierCount() <= 0) {
					a.getUnits().remove(j);
				}
				if(a.getUnits().get(j).getCurrentSoldierCount() <= 0) {
					Unit u = a.getUnits().get(j);
					a.getUnits().remove(j);
					if(u instanceof Archer) {
						setGameLog(getGameLog() + "Level " + u.getLevel() + " " + "Archer");
					}
					if(u instanceof Infantry) {
						setGameLog(getGameLog() + "Level " + u.getLevel() + " " + "Infantry");
					}
					if(u instanceof Cavalry) {
						setGameLog(getGameLog() + "Level " + u.getLevel() + " " + "Cavalry");
					}
					setGameLog(getGameLog() + " has died. \n");
				}
			}
		}
		for(int i = 0; i < this.getAvailableCities().size(); i++) {
			City c = this.getAvailableCities().get(i);
			if(c.getTurnsUnderSiege() >= 3) {
				c.setUnderSiege(false);
			}
			if(c.isUnderSiege()) {
				c.setTurnsUnderSiege(c.getTurnsUnderSiege() + 1);
				for(int j = 0; j < c.getDefendingArmy().getUnits().size(); j++) {
					c.getDefendingArmy().getUnits().get(j).setCurrentSoldierCount((int) (c.getDefendingArmy().getUnits().get(j).getCurrentSoldierCount() * 0.9));
				}
				setGameLog(getGameLog() + "The siege of " + c.getName() + " continues. The units of " + c.getName() + " lose 10% of their soldiers. \n");
				if(c.getTurnsUnderSiege() >= 3) {
					c.setUnderSiege(false);
					setGameLog(getGameLog() + "The siege of " + c.getName() + " has ended. Attack or leave! \n");
				}
			}
		}
		if(won()) {
			JOptionPane.showMessageDialog(null, "Congrats, you won!");
			Main.endGame();
		}
		if(!won() && isGameOver()) {
			JOptionPane.showMessageDialog(null, "Alas, you have lost the game.");
			Main.endGame();
		}
		
	}

	public String getGameLog() {
		return gameLog;
	}

	public void setGameLog(String gameLog) {
		this.gameLog = gameLog;
	}

}
