package exceptions;

public class UnitFullCapacityException {

}
