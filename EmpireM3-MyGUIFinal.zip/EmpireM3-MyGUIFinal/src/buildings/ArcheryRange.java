package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxRecruitedException;
import units.Unit;
import units.Archer;

public class ArcheryRange extends MilitaryBuilding {

	public ArcheryRange() {
		super(1500, 800, 400);

	}
	public Unit recruit() throws BuildingInCoolDownException, MaxRecruitedException{
		if (this.getCurrentRecruit() >= 3) 
        	throw new MaxRecruitedException();
       
		if (this.isCoolDown() == true) 
			throw new BuildingInCoolDownException();
		
		
		if (this.getLevel()==3) {
			
			this.setCurrentRecruit(this.getCurrentRecruit()+1);
			return new Archer(3,70,0.5,0.6,0.7);	
		    }
		
		if (this.getLevel()==2) {
			
			this.setCurrentRecruit(this.getCurrentRecruit()+1);
			return new Archer(2,60,0.4,0.5,0.6);
		   }  
		
		this.setCurrentRecruit(this.getCurrentRecruit()+1);
			return new Archer(1,60,0.4,0.5,0.6);}
		
	public Unit couldRecruit(){
		if (this.getLevel()==3)return new Archer(3,70,0.5,0.6,0.7);
		if (this.getLevel()==2)return new Archer(2,60,0.4,0.5,0.6);
		return new Archer(1,60,0.4,0.5,0.6);
	}
}
