package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxRecruitedException;
import units.Cavalry;
import units.Unit;

public class Stable extends MilitaryBuilding {

	public Stable() {
		super(2500, 1500, 600);

	}
	public Unit recruit() throws BuildingInCoolDownException, MaxRecruitedException{
        if (this.getCurrentRecruit() >= 3) 
        	throw new MaxRecruitedException();
        
		if (this.isCoolDown() == true) 
			throw new BuildingInCoolDownException();
		
		
		if (this.getLevel()==3) {
			this.setCurrentRecruit(this.getCurrentRecruit() +1 );
			return new Cavalry(3,60,0.7,0.8,0.9);	
		    }
		
		if (this.getLevel()==2) {
			this.setCurrentRecruit(this.getCurrentRecruit() +1 );
			return new Cavalry(2,40,0.6,0.7,0.75);
			
			
		   }  
		
			this.setCurrentRecruit(this.getCurrentRecruit() +1 );
			return new Cavalry(1,40,0.6,0.7,0.75);}
	
	public Unit couldRecruit(){
		if (this.getLevel()==3) return new Cavalry(3,60,0.7,0.8,0.9);	
		if (this.getLevel()==2) return new Cavalry(2,40,0.6,0.7,0.75);
		return new Cavalry(1,40,0.6,0.7,0.75);
	}

}
