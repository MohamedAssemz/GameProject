package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxRecruitedException;
import units.Infantry;
import units.Unit;

public class Barracks extends MilitaryBuilding {

	public Barracks() {
		super(2000, 1000, 500);

	}
	
public Unit recruit() throws BuildingInCoolDownException, MaxRecruitedException{
		if (this.getCurrentRecruit() >= 3) 
        	throw new MaxRecruitedException();
       
		if (this.isCoolDown() == true)
			throw new BuildingInCoolDownException();
		
		if (this.getLevel()==3) {
			this.setCurrentRecruit(this.getCurrentRecruit()+1);
			return new Infantry(3,60,0.6,0.7,0.8);}
		
		if (this.getLevel()==2) {
			this.setCurrentRecruit(this.getCurrentRecruit()+1);
			return new Infantry(2,50,0.5,0.6,0.7);}
		
			this.setCurrentRecruit(this.getCurrentRecruit()+1);
			return new Infantry(1,50,0.5,0.6,0.7);}

public Unit couldRecruit(){
	if (this.getLevel()==3) {return new Infantry(3,60,0.6,0.7,0.8);}
	if (this.getLevel()==2) { return new Infantry(2,50,0.5,0.6,0.7);}
	return new Infantry(1,50,0.5,0.6,0.7);}
}
