package buildings;

import exceptions.BuildingInCoolDownException;
import exceptions.MaxLevelException;

public abstract class EconomicBuilding extends Building {

	public EconomicBuilding(int cost, int upgradeCost) {
		super(cost, upgradeCost);
	}
	public abstract int harvest() ;
	
	public void upgrade() throws BuildingInCoolDownException, MaxLevelException{
		if( this instanceof Farm) {
			
			if (this.getLevel() == 1) {
				if ( this.isCoolDown()== true )
					throw new BuildingInCoolDownException();
				else
				this.setLevel(2);
				this.setCoolDown(true);
				this.setUpgradeCost(700);
			}
			else if (this.getLevel() == 2)
				throw new MaxLevelException();
		}
		else 
			if( this instanceof Market) {
				
				if (this.getLevel() == 1) {
					if ( this.isCoolDown()== true )
						throw new BuildingInCoolDownException();
					else
					this.setLevel(2);
					this.setCoolDown(true);
					this.setUpgradeCost(1000);
				}
				else if (this.getLevel() == 2)
					throw new MaxLevelException();
			}
	}
}
